﻿namespace HelloTaskApp
{
    interface IRandomGenerator
    {
        double GetRandom();
    }
}